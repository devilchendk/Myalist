package archive

import (
	_ "github.com/alist-org/alist/v3/internal/archive/archives"
	_ "github.com/alist-org/alist/v3/internal/archive/iso9660"
	_ "github.com/alist-org/alist/v3/internal/archive/rardecode"
	_ "github.com/alist-org/alist/v3/internal/archive/sevenzip"
	_ "github.com/alist-org/alist/v3/internal/archive/zip"
)
